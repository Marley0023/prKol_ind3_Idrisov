﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prKol_ind3_Idrisov
{
    public partial class Form1 : Form
    {
        ArrayList addresses = new ArrayList();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string street = textBox1.Text;
            string city = textBox2.Text;
            string zipCode = textBox3.Text;

            Address newAddress = new Address(street, city, zipCode);
            addresses.Add(newAddress);
            UpdateAddressList();

            MessageBox.Show("Почтовый адрес успешно добавлен!");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                string street = textBox1.Text;
                string city = textBox2.Text;
                string zipCode = textBox3.Text;

                Address editedAddress = new Address(street, city, zipCode);
                addresses[listBox1.SelectedIndex] = editedAddress;
                UpdateAddressList();
                MessageBox.Show("Почтовый адрес успешно изменен!");
            }
            else
            {
                MessageBox.Show("Выберите адрес для изменения.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                addresses.RemoveAt(listBox1.SelectedIndex);
                UpdateAddressList();
                MessageBox.Show("Почтовый адрес успешно удален!");
            }
            else
            {
                MessageBox.Show("Выберите адрес для удаления.");
            }
        }
        private void UpdateAddressList()
        {
            listBox1.Items.Clear();
            foreach (Address address in addresses)
            {
                listBox1.Items.Add(address.ToString());
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }
        


    }

}
